year=2023
if year%4==0:
  print("leap year")
else:
  print("Not a leap year")